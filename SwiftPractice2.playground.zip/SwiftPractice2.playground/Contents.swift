import Foundation

// Define a struct for the product
struct Product {
    var id: UUID
    var name: String
    var price: Double
    var quantity: Int
}

// Function to generate a random product ID
func generateProductID() -> UUID {
    return UUID()
}

// Function to generate random product name
func generateProductName() -> String {
    let adjectives = ["Red", "Green", "Blue", "Yellow", "Black", "White"]
    let nouns = ["Shirt", "Pants", "Shoes", "Hat", "Jacket", "Socks"]
    let randomAdjective = adjectives.randomElement()!
    let randomNoun = nouns.randomElement()!
    return "\(randomAdjective) \(randomNoun)"
}

// Function to generate random product price
func generateProductPrice() -> Double {
    return Double.random(in: 10.0...100.0)
}

// Function to generate random product quantity
func generateProductQuantity() -> Int {
    return Int.random(in: 1...100)
}

// Generate a list of products
var products = [Product]()

for _ in 1...10 {
    let product = Product(id: generateProductID(),
                          name: generateProductName(),
                          price: generateProductPrice(),
                          quantity: generateProductQuantity())
    products.append(product)
}

// Display the list of products
print("Inventory:")
for product in products {
    print("ID: \(product.id), Name: \(product.name), Price: $\(product.price), Quantity: \(product.quantity)")
}

// Calculate total inventory value
var totalValue = 0.0
for product in products {
    totalValue += product.price * Double(product.quantity)
}

print("Total Inventory Value: $\(totalValue)")

// Create a dictionary to store product IDs and their corresponding quantities sold
var productsSold = [UUID: Int]()

// Simulate selling some products
for _ in 1...5 {
    let randomIndex = Int.random(in: 0..<products.count)
    let product = products[randomIndex]
    let quantitySold = Int.random(in: 1...product.quantity)
    
    // Update product quantity
    products[randomIndex].quantity -= quantitySold
    
    // Update productsSold dictionary
    if let existingQuantity = productsSold[product.id] {
        productsSold[product.id] = existingQuantity + quantitySold
    } else {
        productsSold[product.id] = quantitySold
    }
}

// Display products sold
print("\nProducts Sold:")
for (productID, quantitySold) in productsSold {
    if let product = products.first(where: { $0.id == productID }) {
        print("Name: \(product.name), Quantity Sold: \(quantitySold)")
    }
}

// Display updated inventory
print("\nUpdated Inventory:")
for product in products {
    print("ID: \(product.id), Name: \(product.name), Price: $\(product.price), Quantity: \(product.quantity)")
}
